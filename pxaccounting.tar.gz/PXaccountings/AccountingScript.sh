#!/bin/bash


function get_pid {
   PID=`pidof -x PXaccounting`
}

function stop {
   get_pid
   if [ -z $PID ]; then
      echo "PXaccounting service is not running."
      exit 1
   else
      echo -n "Stopping server.."
      kill -15 $PID
      $(ps -ef | grep 'PXaccounting' | grep -v grep | grep -v vim | awk '{print $2}' | xargs kill -15)
      COUNT=1
      while [ -z $PID ]
      do
          sleep 1
          get_pid
          COUNT=$(( $COUNT + 1 ))
          if [ $COUNT -gt 9 ]; then
              break;
          fi
          printf "... $PID  $COUNT ...\n"
      done
      #sleep 10
      echo ".. Done."
   fi
}

function start {
   get_pid
   if [ -z $PID ]; then
      echo  "Starting accounting service.."
      nohup ./PXaccounting &
      get_pid
      echo "Done. PID=$PID"
   else
      echo "PXaccounting service is already running, PID=$PID"
   fi
}

function restart {
   echo  "Restarting PXaccounting service.."
   get_pid
   if [ -z $PID ]; then
      start
   else
      stop
      sleep 1
      start
   fi
}


function status {
   get_pid
   if [ -z  $PID ]; then
      echo "Accounting service is not running."
      exit 1
   else
      echo "Accounting service is running, PID=$PID"
   fi
}


case "$1" in
   start)
      start
   ;;
   stop)
      stop
   ;;
   restart)
      restart
   ;;
   status)
      status
   ;;
   *)
      echo "Usage: $0 {start|stop|restart|status}"
esac
